<?php include __DIR__ . '/templates/header.php'; ?>

    <div class="not-found">
        <img src="/images/huh.png"/>
        <h1>Sorry, we have not found the page that you are looking for</h1>
    </div>

<?php include __DIR__ . '/templates/footer.php' ?>